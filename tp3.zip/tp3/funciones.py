import json
import random
import string
from datetime import datetime
from datetime import timedelta
import os
import pickle
import urllib.request
from fpdf import FPDF
import qrcode

def crearPlaca():
    """
    Funcionamiento: genera una placa aleatoria con 3 letras mayusculas y 3 numeros
    Entradas: no recibe parametros
    Salidas:
    - placa (str): placa generada con formato ABC-123
    """
    letras = ''.join(random.choices(string.ascii_uppercase, k=3))
    numeros = ''.join(random.choices(string.digits, k=3))
    return letras + "-" + numeros

def crearPlacaUnica(diccionario, diccionarioTemporal):
    """
    Funcionamiento: genera una placa aleatoria que no exista en el diccionario global ni en el temporal
    Entradas:
    - diccionario (dict): diccionario global de vehiculos estacionados
    - diccionarioTemporal (dict): diccionario temporal de vehiculos generados en la operacion actual
    Salidas:
    - placa (str): placa unica generada
    """
    placa = crearPlaca()
    placaRepetida = True
    while placaRepetida:
        placaRepetida = False
        if placa in diccionario:
            placaRepetida = True
        if placa in diccionarioTemporal:
            placaRepetida = True
        if placaRepetida:
            placa = crearPlaca()
    return placa

def redondearHaciaArriba(numero):
    """
    Funcionamiento: redondea un numero decimal hacia el siguiente entero si tiene parte decimal
    Entradas:
    - numero (float): numero a redondear
    Salidas:
    - resultado (int): numero redondeado hacia arriba
    """
    entero = int(numero)
    if numero > entero:
        return entero + 1
    return entero

def calcularCantidadEspeciales(tamanioEstacionamiento):
    """
    Funcionamiento: calcula la cantidad de espacios especiales (discapacidad) segun el tamanio del estacionamiento
    Entradas:
    - tamanioEstacionamiento (int): cantidad total de espacios del estacionamiento
    Salidas:
    - cantidadEspeciales (int): cantidad de espacios especiales calculada
    """
    cantidadEspeciales = redondearHaciaArriba(tamanioEstacionamiento * 0.05)
    if cantidadEspeciales < 2:
        cantidadEspeciales = 2
    if cantidadEspeciales > tamanioEstacionamiento:
        cantidadEspeciales = tamanioEstacionamiento
    return cantidadEspeciales

def calcularTopeMasivo(tamanioEstacionamiento, tieneElectrico):
    """
    Funcionamiento: calcula la cantidad maxima de vehiculos que se pueden cargar de forma masiva en espacios generales
    Entradas:
    - tamanioEstacionamiento (int): cantidad total de espacios del estacionamiento
    - tieneElectrico (bool): indica si el estacionamiento tiene espacio para vehiculos electricos
    Salidas:
    - topeMasivo (int): cantidad maxima de espacios generales disponibles para carga masiva
    """
    cantidadEspeciales = calcularCantidadEspeciales(tamanioEstacionamiento)
    cantidadElectricos = 0
    if tieneElectrico:
        cantidadElectricos = 1
    cantidadGeneral = tamanioEstacionamiento - cantidadEspeciales - cantidadElectricos
    if cantidadGeneral <= 0:
        return 0
    cantidadLibreClientes = redondearHaciaArriba(cantidadGeneral * 0.05)
    topeMasivo = cantidadGeneral - cantidadLibreClientes
    if topeMasivo < 0:
        topeMasivo = 0
    return topeMasivo

def guardarConfiguracion(configuracion, archivoConfiguracion):
    """
    Funcionamiento: guarda el diccionario de configuracion en un archivo mediante pickle
    Entradas:
    - configuracion (dict): datos de configuracion del estacionamiento
    - archivoConfiguracion (str): ruta del archivo donde se guarda la configuracion
    Salidas: no retorna nada
    """
    with open(archivoConfiguracion, "wb") as archivo:
        pickle.dump(configuracion, archivo)

def cargarConfiguracion(archivoConfiguracion):
    """
    Funcionamiento: carga la configuracion del estacionamiento desde un archivo pickle si existe
    Entradas:
    - archivoConfiguracion (str): ruta del archivo de configuracion
    Salidas:
    - configuracion (dict o None): configuracion cargada, o None si no existe o es invalida
    """
    if not os.path.exists(archivoConfiguracion):
        return None
    try:
        with open(archivoConfiguracion, "rb") as archivo:
            configuracion = pickle.load(archivo)
        if isinstance(configuracion, dict):
            return configuracion
        return None
    except Exception:
        return None

def guardarBaseDatos(listaObjetos, archivoBaseDatos):
    """
    Funcionamiento: guarda la lista de objetos del estacionamiento en un archivo mediante pickle
    Entradas:
    - listaObjetos (list): lista de objetos Estacionamiento a guardar
    - archivoBaseDatos (str): ruta del archivo donde se guarda la base de datos
    Salidas: no retorna nada
    """
    with open(archivoBaseDatos, "wb") as archivo:
        pickle.dump(listaObjetos, archivo)

def cargarBaseDatos(archivoBaseDatos):
    """
    Funcionamiento: carga la lista de objetos del estacionamiento desde un archivo pickle si existe
    Entradas:
    - archivoBaseDatos (str): ruta del archivo de la base de datos
    Salidas:
    - listaObjetos (list): lista de objetos cargados, o lista vacia si no existe o es invalida
    """
    if not os.path.exists(archivoBaseDatos):
        return []
    try:
        with open(archivoBaseDatos, "rb") as archivo:
            listaObjetos = pickle.load(archivo)
        if isinstance(listaObjetos, list):
            return listaObjetos
        return []
    except Exception:
        return []

def crearFechaHoraEntradaAleatoria():
    """
    Funcionamiento: genera una fecha y hora de entrada aleatoria entre la hora de apertura (7am) y la hora actual
    Entradas: no recibe parametros
    Salidas:
    - fechaHoraEntrada (str): fecha y hora generada con formato "%Y-%m-%d %H:%M:%S"
    """
    horaActual = datetime.now()
    horaApertura = horaActual.replace(hour=7, minute=0, second=0, microsecond=0)
    if horaActual < horaApertura:
        return horaActual.strftime("%Y-%m-%d %H:%M:%S")
    segundosMaximos = int((horaActual - horaApertura).total_seconds())
    if segundosMaximos <= 0:
        return horaActual.strftime("%Y-%m-%d %H:%M:%S")
    segundosAleatorios = random.randint(0, segundosMaximos)
    fechaHoraEntrada = horaApertura + timedelta(seconds=segundosAleatorios)
    return fechaHoraEntrada.strftime("%Y-%m-%d %H:%M:%S")

def calcularMontoEstadia(fechaHoraEntrada, fechaHoraSalida, montoHora, tiempoDeGracia):
    """
    Funcionamiento: calcula el monto a pagar por una estadia segun las horas cobradas y el tiempo de gracia
    Entradas:
    - fechaHoraEntrada (str): fecha y hora de entrada del vehiculo
    - fechaHoraSalida (str): fecha y hora de salida del vehiculo
    - montoHora (int): monto que se cobra por cada hora
    - tiempoDeGracia (int): minutos de gracia antes de empezar a cobrar
    Salidas:
    - monto (int): monto total a pagar por la estadia
    """
    entrada = datetime.strptime(fechaHoraEntrada, "%Y-%m-%d %H:%M:%S")
    salida = datetime.strptime(fechaHoraSalida, "%Y-%m-%d %H:%M:%S")
    minutosEstadia = (salida - entrada).total_seconds() / 60
    if minutosEstadia <= tiempoDeGracia:
        return 0
    horasEstadia = minutosEstadia / 60
    horasCobradas = redondearHaciaArriba(horasEstadia)
    return horasCobradas * montoHora

def obtenerDatoCarro(carro, llave, valorDefecto):
    """
    Funcionamiento: obtiene el valor de una llave dentro del diccionario de un carro, o un valor por defecto si no existe o esta vacio
    Entradas:
    - carro (dict): diccionario con los datos del vehiculo obtenidos de la API
    - llave (str): nombre de la llave a buscar
    - valorDefecto (str): valor que se retorna si la llave no existe o esta vacia
    Salidas:
    - valor (str): valor encontrado o el valor por defecto
    """
    if llave in carro:
        if carro[llave] is not None:
            if str(carro[llave]).strip() != "":
                return str(carro[llave])
    return valorDefecto

def obtenerDatosVehiculos(cantidadVehiculos, urlApiMockaroo):
    """
    Funcionamiento: consulta la API de Mockaroo para obtener una lista de datos de vehiculos aleatorios
    Entradas:
    - cantidadVehiculos (int): cantidad de vehiculos a solicitar a la API
    - urlApiMockaroo (str): URL base de la API de Mockaroo
    Salidas:
    - datosVehiculos (list): lista de diccionarios con los datos de los vehiculos obtenidos
    """
    separador = "?"
    if "?" in urlApiMockaroo:
        separador = "&"
    urlCompleta = urlApiMockaroo + separador + "count=" + str(cantidadVehiculos)
    respuesta = urllib.request.urlopen(urlCompleta, timeout=15)
    contenido = respuesta.read().decode("utf-8")
    datosVehiculos = json.loads(contenido)
    if isinstance(datosVehiculos, dict):
        datosConvertidos = []
        datosConvertidos.append(datosVehiculos)
        datosVehiculos = datosConvertidos
    if not isinstance(datosVehiculos, list):
        raise ValueError()
    return datosVehiculos

def obtenerMarcasYTiposApi(urlApiMockaroo, catalogoMarcas, catalogoTipos):
    """
    Funcionamiento: obtiene marcas y tipos de vehiculo disponibles a partir de una muestra de datos de la API, usando los catalogos como respaldo
    Entradas:
    - urlApiMockaroo (str): URL base de la API de Mockaroo
    - catalogoMarcas (dict): catalogo de marcas conocidas
    - catalogoTipos (dict): catalogo de tipos de vehiculo conocidos
    Salidas:
    - marcasApi (list): lista de marcas obtenidas o del catalogo si la API falla
    - tiposApi (list): lista de tipos obtenidos o del catalogo si la API falla
    """
    try:
        datosVehiculos = obtenerDatosVehiculos(10, urlApiMockaroo)
        marcasApi = []
        tiposApi = []
        for carro in datosVehiculos:
            marcaTexto = obtenerDatoCarro(carro, "Marca", "")
            tipoTexto = obtenerDatoCarro(carro, "Tipo", "")
            if marcaTexto in catalogoMarcas.values() and marcaTexto not in marcasApi:
                marcasApi.append(marcaTexto)
            if tipoTexto in catalogoTipos.values() and tipoTexto not in tiposApi:
                tiposApi.append(tipoTexto)
        marcasApi.sort()
        tiposApi.sort()
        if len(marcasApi) == 0:
            marcasApi = list(catalogoMarcas.values())
        if len(tiposApi) == 0:
            tiposApi = list(catalogoTipos.values())
        return marcasApi, tiposApi
    except Exception:
        return list(catalogoMarcas.values()), list(catalogoTipos.values())

def crearDiccionarioVehiculos(diccionario, datosVehiculos, ubicacionesLibres, cantidadVehiculos, catalogoMarcas, catalogoColores, catalogoTipos):
    """
    Funcionamiento: crea un diccionario de vehiculos nuevos a partir de los datos de la API, asignandoles placa y ubicacion
    Entradas:
    - diccionario (dict): diccionario global de vehiculos estacionados
    - datosVehiculos (list): datos de vehiculos obtenidos de la API
    - ubicacionesLibres (list): ubicaciones generales disponibles
    - cantidadVehiculos (int): cantidad de vehiculos a crear
    - catalogoMarcas (dict): catalogo de marcas
    - catalogoColores (dict): catalogo de colores
    - catalogoTipos (dict): catalogo de tipos de vehiculo
    Salidas:
    - diccionarioVehiculos (dict): diccionario con los nuevos vehiculos creados
    """
    diccionarioVehiculos = {}
    contador = 0
    for carro in datosVehiculos:
        if contador < cantidadVehiculos:
            if contador < len(ubicacionesLibres):
                placa = crearPlacaUnica(diccionario, diccionarioVehiculos)
                marcaTexto = obtenerDatoCarro(carro, "Marca", "Toyota")
                colorTexto = obtenerDatoCarro(carro, "Color", "Azul")
                tipoTexto = obtenerDatoCarro(carro, "Tipo", "Automovil")
                marca = convertirTextoAId(catalogoMarcas, marcaTexto, 0)
                color = convertirTextoAId(catalogoColores, colorTexto, 0)
                tipo = convertirTextoAId(catalogoTipos, tipoTexto, 0)
                ubicacion = str(ubicacionesLibres[contador])
                fechaHoraEntrada = crearFechaHoraEntradaAleatoria()
                fechaHoraSalida = ""
                monto = 0
                tipoPago = 0
                diccionarioVehiculos[placa] = [marca, color, tipo, ubicacion, fechaHoraEntrada, fechaHoraSalida, monto, tipoPago]
                contador += 1
    return diccionarioVehiculos

def agregarDiccionarioGlobal(diccionario, diccionarioVehiculos):
    """
    Funcionamiento: agrega los vehiculos de un diccionario temporal al diccionario global de vehiculos estacionados
    Entradas:
    - diccionario (dict): diccionario global de vehiculos estacionados
    - diccionarioVehiculos (dict): diccionario con los vehiculos a agregar
    Salidas: no retorna nada
    """
    for placa, datos in diccionarioVehiculos.items():
        diccionario[placa] = datos

def reconstruirDiccionarioDesdeObjetos(listaObjetos):
    """
    Funcionamiento: reconstruye el diccionario de vehiculos activos a partir de la lista de objetos guardados, incluyendo solo los que no tienen fecha de salida
    Entradas:
    - listaObjetos (list): lista de objetos Estacionamiento cargados de la base de datos
    Salidas:
    - diccionario (dict): diccionario de vehiculos actualmente estacionados
    """
    diccionario = {}
    for objeto in listaObjetos:
        placa = objeto.info[0]
        marca = objeto.info[1]
        color = objeto.info[2]
        tipo = objeto.info[3]
        ubicacion = objeto.estadia[0]
        fechaHoraEntrada = objeto.estadia[1]
        fechaHoraSalida = objeto.estadia[2]
        monto = objeto.pago[0]
        tipoPago = objeto.pago[1]
        if fechaHoraSalida == "":
            diccionario[placa] = [marca, color, tipo, ubicacion, fechaHoraEntrada, fechaHoraSalida, monto, tipoPago]
    return diccionario

def reconstruirEspaciosDesdeObjetos(listaObjetos, espacios):
    """
    Funcionamiento: marca como ocupados los espacios correspondientes a los vehiculos activos segun la lista de objetos
    Entradas:
    - listaObjetos (list): lista de objetos Estacionamiento cargados de la base de datos
    - espacios (list): lista de espacios del estacionamiento
    Salidas:
    - espacios (list): lista de espacios actualizada con los carros ocupando su ubicacion
    """
    for objeto in listaObjetos:
        placa = objeto.info[0]
        ubicacion = objeto.estadia[0]
        fechaHoraSalida = objeto.estadia[2]
        if fechaHoraSalida == "":
            try:
                indice = int(ubicacion) - 1
                if indice >= 0 and indice < len(espacios):
                    espacios[indice]["carro"] = placa
            except ValueError:
                pass
    return espacios

def crearCarpetaSiNoExiste(nombreCarpeta):
    """
    Funcionamiento: crea una carpeta en el sistema de archivos si esta no existe
    Entradas:
    - nombreCarpeta (str): ruta de la carpeta a crear
    Salidas: no retorna nada
    """
    if not os.path.exists(nombreCarpeta):
        os.makedirs(nombreCarpeta)

def limpiarNombreArchivo(texto):
    """
    Funcionamiento: reemplaza los caracteres invalidos de un texto para que pueda usarse como nombre de archivo
    Entradas:
    - texto (str): texto original a limpiar
    Salidas:
    - textoLimpio (str): texto sin caracteres invalidos
    """
    textoLimpio = str(texto)
    caracteresInvalidos = ["\\", "/", ":", "*", "?", '"', "<", ">", "|"]
    for caracter in caracteresInvalidos:
        textoLimpio = textoLimpio.replace(caracter, "-")
    return textoLimpio

def crearTextoQrVoucher(objeto, catalogoMarcas, catalogoTipos):
    """
    Funcionamiento: arma el texto que se codifica en el codigo QR de un voucher de entrada
    Entradas:
    - objeto (Estacionamiento): objeto con la informacion del vehiculo
    - catalogoMarcas (dict): catalogo de marcas
    - catalogoTipos (dict): catalogo de tipos de vehiculo
    Salidas:
    - textoQr (str): texto a codificar en el codigo QR
    """
    placa = objeto.info[0]
    marca = convertirIdATexto(catalogoMarcas, objeto.info[1], "Desconocida")
    tipo = convertirIdATexto(catalogoTipos, objeto.info[3], "Desconocido")
    fechaHoraEntrada = objeto.estadia[1]
    textoQr = str(placa) + "-" + str(marca) + "-" + str(tipo) + "-" + str(fechaHoraEntrada)
    return textoQr

def crearNombreVoucher(objeto):
    """
    Funcionamiento: genera el nombre de archivo del voucher de entrada a partir de la placa y la fecha de entrada
    Entradas:
    - objeto (Estacionamiento): objeto con la informacion del vehiculo
    Salidas:
    - nombreArchivo (str): nombre del archivo PDF del voucher
    """
    placa = objeto.info[0]
    fechaHoraEntrada = objeto.estadia[1]
    try:
        fecha = datetime.strptime(fechaHoraEntrada, "%Y-%m-%d %H:%M:%S")
        fechaTexto = fecha.strftime("%d-%m-%Y_%H-%M")
    except ValueError:
        fechaTexto = limpiarNombreArchivo(fechaHoraEntrada)
    nombreArchivo = "voucher_#" + str(placa) + "_" + fechaTexto + ".pdf"
    nombreArchivo = limpiarNombreArchivo(nombreArchivo)
    return nombreArchivo

def crearVoucherPdf(objeto, carpetaVouchers, catalogoMarcas, catalogoColores, catalogoTipos):
    """
    Funcionamiento: genera el archivo PDF del voucher de entrada de un vehiculo, incluyendo su codigo QR
    Entradas:
    - objeto (Estacionamiento): objeto con la informacion del vehiculo
    - carpetaVouchers (str): carpeta donde se guardan los vouchers
    - catalogoMarcas (dict): catalogo de marcas
    - catalogoColores (dict): catalogo de colores
    - catalogoTipos (dict): catalogo de tipos de vehiculo
    Salidas:
    - rutaPdf (str): ruta del archivo PDF generado
    """
    crearCarpetaSiNoExiste(carpetaVouchers)
    placa = objeto.info[0]
    marca = convertirIdATexto(catalogoMarcas, objeto.info[1], "Desconocida")
    color = convertirIdATexto(catalogoColores, objeto.info[2], "Desconocido")
    tipo = convertirIdATexto(catalogoTipos, objeto.info[3], "Desconocido")
    ubicacion = objeto.estadia[0]
    fechaHoraEntrada = objeto.estadia[1]
    nombreArchivo = crearNombreVoucher(objeto)
    rutaPdf = os.path.join(carpetaVouchers, nombreArchivo)
    textoQr = crearTextoQrVoucher(objeto, catalogoMarcas, catalogoTipos)
    imagenQr = qrcode.make(textoQr)
    nombreQr = "qr_" + limpiarNombreArchivo(str(placa)) + ".png"
    rutaQr = os.path.join(carpetaVouchers, nombreQr)
    imagenQr.save(rutaQr)
    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("Arial", "B", 16)
    pdf.cell(0, 10, "Voucher de Estacionamiento", ln=True, align="C")
    pdf.ln(10)
    pdf.set_font("Arial", "", 12)
    pdf.cell(0, 8, "Placa: " + str(placa), ln=True)
    pdf.cell(0, 8, "Marca: " + str(marca), ln=True)
    pdf.cell(0, 8, "Color: " + str(color), ln=True)
    pdf.cell(0, 8, "Tipo: " + str(tipo), ln=True)
    pdf.cell(0, 8, "Ubicacion: " + str(ubicacion), ln=True)
    pdf.cell(0, 8, "Fecha y hora de entrada: " + str(fechaHoraEntrada), ln=True)
    pdf.ln(10)
    pdf.cell(0, 8, "Codigo QR:", ln=True)
    pdf.image(rutaQr, x=80, y=100, w=50, h=50)
    pdf.output(rutaPdf)
    try:
        os.remove(rutaQr)
    except OSError:
        pass
    return rutaPdf

def crearVouchersMasivos(diccionarioVehiculos, listaObjetos, carpetaVouchers, catalogoMarcas, catalogoColores, catalogoTipos):
    """
    Funcionamiento: genera los vouchers en PDF de todos los vehiculos incluidos en una carga masiva
    Entradas:
    - diccionarioVehiculos (dict): diccionario con los vehiculos cargados masivamente
    - listaObjetos (list): lista de objetos Estacionamiento
    - carpetaVouchers (str): carpeta donde se guardan los vouchers
    - catalogoMarcas (dict): catalogo de marcas
    - catalogoColores (dict): catalogo de colores
    - catalogoTipos (dict): catalogo de tipos de vehiculo
    Salidas:
    - cantidadVouchers (int): cantidad de vouchers generados
    """
    cantidadVouchers = 0
    for objeto in listaObjetos:
        placaObjeto = objeto.info[0]
        if placaObjeto in diccionarioVehiculos:
            crearVoucherPdf(objeto, carpetaVouchers, catalogoMarcas, catalogoColores, catalogoTipos)
            cantidadVouchers += 1
    return cantidadVouchers

def crearFacturaPdf(objeto, carpetaVouchers, catalogoMarcas, catalogoColores, catalogoTipos, catalogoTiposPago):
    """
    Funcionamiento: genera el archivo PDF de la factura de salida de un vehiculo, incluyendo su codigo QR
    Entradas:
    - objeto (Estacionamiento): objeto con la informacion del vehiculo
    - carpetaVouchers (str): carpeta donde se guardan las facturas
    - catalogoMarcas (dict): catalogo de marcas
    - catalogoColores (dict): catalogo de colores
    - catalogoTipos (dict): catalogo de tipos de vehiculo
    - catalogoTiposPago (dict): catalogo de tipos de pago
    Salidas:
    - rutaPdf (str): ruta del archivo PDF generado
    """
    crearCarpetaSiNoExiste(carpetaVouchers)
    placa = objeto.info[0]
    marca = convertirIdATexto(catalogoMarcas, objeto.info[1], "Desconocida")
    color = convertirIdATexto(catalogoColores, objeto.info[2], "Desconocido")
    tipo = convertirIdATexto(catalogoTipos, objeto.info[3], "Desconocido")
    ubicacion = objeto.estadia[0]
    fechaHoraEntrada = objeto.estadia[1]
    fechaHoraSalida = objeto.estadia[2]
    monto = objeto.pago[0]
    tipoPagoTexto = convertirIdATexto(catalogoTiposPago, objeto.pago[1], "Desconocido")
    try:
        fecha = datetime.strptime(fechaHoraSalida, "%Y-%m-%d %H:%M:%S")
        fechaTexto = fecha.strftime("%d-%m-%Y_%H-%M")
    except:
        fechaTexto = limpiarNombreArchivo(fechaHoraSalida)
    nombreArchivo = "factura_#" + str(placa) + "_" + fechaTexto + ".pdf"
    nombreArchivo = limpiarNombreArchivo(nombreArchivo)
    rutaPdf = os.path.join(carpetaVouchers, nombreArchivo)
    textoQr = str(placa) + "-" + str(marca) + "-" + str(color) + "-" + str(tipo)
    textoQr += "-" + str(ubicacion) + "-" + str(fechaHoraEntrada) + "-" + str(fechaHoraSalida)
    textoQr += "-" + str(tipoPagoTexto) + "-" + str(monto)
    imagenQr = qrcode.make(textoQr)
    nombreQr = "qr_factura_" + limpiarNombreArchivo(str(placa)) + ".png"
    rutaQr = os.path.join(carpetaVouchers, nombreQr)
    imagenQr.save(rutaQr)
    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("Arial", "B", 16)
    pdf.cell(0, 10, "Factura de Estacionamiento", ln=True, align="C")
    pdf.ln(5)
    pdf.set_font("Arial", "", 12)
    pdf.cell(0, 8, "Placa: " + str(placa), ln=True)
    pdf.cell(0, 8, "Marca: " + str(marca), ln=True)
    pdf.cell(0, 8, "Color: " + str(color), ln=True)
    pdf.cell(0, 8, "Tipo: " + str(tipo), ln=True)
    pdf.cell(0, 8, "Ubicacion: " + str(ubicacion), ln=True)
    pdf.cell(0, 8, "Fecha y hora de entrada: " + str(fechaHoraEntrada), ln=True)
    pdf.cell(0, 8, "Fecha y hora de salida: " + str(fechaHoraSalida), ln=True)
    pdf.cell(0, 8, "Tipo de pago: " + str(tipoPagoTexto), ln=True)
    pdf.cell(0, 8, "Monto: " + str(monto), ln=True)
    pdf.ln(10)
    pdf.cell(0, 8, "Codigo QR:", ln=True)
    pdf.image(rutaQr, x=80, y=pdf.get_y(), w=50, h=50)
    pdf.output(rutaPdf)
    try:
        os.remove(rutaQr)
    except OSError:
        pass
    return rutaPdf

def convertirTextoAId(catalogo, texto, idDefecto):
    """
    Funcionamiento: busca el identificador correspondiente a un texto dentro de un catalogo, agregandolo si no existe
    Entradas:
    - catalogo (dict): catalogo de valores con su identificador
    - texto (str): texto a buscar o agregar
    - idDefecto (int): identificador que se retorna si el texto esta vacio
    Salidas:
    - idValor (int): identificador encontrado, agregado, o por defecto
    """
    for idValor, valorTexto in catalogo.items():
        if valorTexto == texto:
            return idValor
    if texto == "":
        return idDefecto
    nuevoId = max(catalogo.keys()) + 1
    catalogo[nuevoId] = texto
    return nuevoId

def convertirIdATexto(catalogo, idValor, textoDefecto):
    """
    Funcionamiento: obtiene el texto correspondiente a un identificador dentro de un catalogo
    Entradas:
    - catalogo (dict): catalogo de valores con su identificador
    - idValor (int): identificador a buscar
    - textoDefecto (str): texto que se retorna si el identificador no existe
    Salidas:
    - texto (str): texto encontrado o el texto por defecto
    """
    if idValor in catalogo:
        return catalogo[idValor]
    return textoDefecto

def imprimirDiccionarioVehiculos(diccionarioVehiculos):
    """
    Funcionamiento: imprime en consola el diccionario de vehiculos cargados en formato JSON legible
    Entradas:
    - diccionarioVehiculos (dict): diccionario de vehiculos a imprimir
    Salidas: no retorna nada
    """
    print("- DICCIONARIO DE VEHICULOS CARGADOS -")
    print(json.dumps(diccionarioVehiculos, indent=4, ensure_ascii=False))
    print("---------------------")
