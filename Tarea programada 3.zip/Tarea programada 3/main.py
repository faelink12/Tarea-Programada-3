from botones import construirVentanaPrincipal
from estacionamiento import denominarEspacios

def main():
    diccionario = {}
    listaObjetos = []
    espaciosEstacionamiento = denominarEspacios()
    archivoBaseDatos = "baseDatosParqueo.pkl"
    carpetaVouchers = "vouchers"
    urlApiMockaroo = "https://my.api.mockaroo.com/vehiculos.json?key=5f760930"
    construirVentanaPrincipal(diccionario, listaObjetos, espaciosEstacionamiento, archivoBaseDatos, carpetaVouchers, urlApiMockaroo)

if __name__ == "__main__":
    main()