import tkinter as tk
from tkinter import messagebox
from estacionamiento import estacionamientoVentana
from estacionamiento import existeEspacioElectrico
from estacionamiento import obtenerUbicacionesGeneralesLibres
from estacionamiento import ocuparEspaciosMasivos
from estacionamiento import agregarObjetosEstacionamiento
from funciones import calcularTopeMasivo
from funciones import obtenerDatosVehiculos
from funciones import crearDiccionarioVehiculos
from funciones import agregarDiccionarioGlobal
from funciones import guardarBaseDatos
from funciones import crearVouchersMasivos
from funciones import imprimirDiccionarioVehiculos

def construirVentanaPrincipal(diccionario, listaObjetos, espaciosEstacionamiento, archivoBaseDatos, carpetaVouchers, urlApiMockaroo):
    app = tk.Tk()
    app.title("Sistema de Parqueo")
    app.geometry("400x600")
    app.resizable(False, False)
    app.config(bg="#2D2F33")
    tk.Label(app, text="Sistema de Parqueo", bg="#2D2F33", fg="White", font=("SansSerif", 16, "bold")).pack(pady=15)
    tk.Label(app, text="1. Vehículos", bg="#2D2F33", fg="white", font=("SansSerif", 9, "italic")).pack()
    tk.Button(app, text="Obtener vehículos", bg="#8B1475", fg="white", font=("SansSerif", 10, "bold"), width=28, pady=8, relief="flat", command=lambda: alClickObtenerVehiculos(diccionario, listaObjetos, espaciosEstacionamiento, archivoBaseDatos, carpetaVouchers, urlApiMockaroo)).pack(pady=4)
    tk.Button(app, text="Ver estacionamiento", bg="#4a4a4a", fg="white", font=("SansSerif", 10), width=28, pady=6, relief="flat", command=lambda: estacionamientoVentana(diccionario, listaObjetos, espaciosEstacionamiento, archivoBaseDatos, carpetaVouchers)).pack(pady=2)
    tk.Label(app, text="2. Reportes", bg="#2D2F33", fg="white", font=("SansSerif", 9, "italic")).pack(pady=(10, 0))
    tk.Button(app, text="Cierre diario", bg="#4a4a4a", fg="white", font=("SansSerif", 10), width=28, pady=6, relief="flat", command=lambda: alClickCierreDiario(listaObjetos)).pack(pady=2)
    tk.Button(app, text="Cierre por tipo de pago", bg="#4a4a4a", fg="white", font=("SansSerif", 10), width=28, pady=6, relief="flat", command=lambda: alClickCierrePorTipoPago(listaObjetos)).pack(pady=2)
    tk.Button(app, text="Exportar cierre diario a CSV", bg="#4a4a4a", fg="white", font=("SansSerif", 10), width=28, pady=6, relief="flat", command=lambda: alClickExportarCSV(listaObjetos)).pack(pady=2)
    tk.Label(app, text="3. Configuración", bg="#2D2F33", fg="white", font=("SansSerif", 9, "italic")).pack(pady=(10, 0))
    tk.Button(app, text="Tamaño del estacionamiento", bg="#4a4a4a", fg="white", font=("SansSerif", 10), width=28, pady=6, relief="flat", command=lambda: alClickTamanioEstacionamiento(espaciosEstacionamiento)).pack(pady=2)
    tk.Button(app, text="Tiempo de gracia en minutos", bg="#4a4a4a", fg="white", font=("SansSerif", 10), width=28, pady=6, relief="flat", command=alClickTiempoDeGracia).pack(pady=2)
    tk.Button(app, text="Modificar monto por hora", bg="#4a4a4a", fg="white", font=("SansSerif", 10), width=28, pady=6, relief="flat", command=alClickModificarMontoPorHora).pack(pady=2)
    tk.Label(app, text="4. Acerca de", bg="#2D2F33", fg="white", font=("SansSerif", 9, "italic")).pack(pady=(10, 0))
    tk.Button(app, text="Acerca de", bg="#8B1475", fg="white", font=("SansSerif", 10, "bold"), width=28, pady=8, relief="flat", command=alClickAcercaDe).pack(pady=4)
    app.mainloop()

def alClickObtenerVehiculos(diccionario, listaObjetos, espaciosEstacionamiento, archivoBaseDatos, carpetaVouchers, urlApiMockaroo):
    try:
        tamanioEstacionamiento = len(espaciosEstacionamiento)
        tieneElectrico = existeEspacioElectrico(espaciosEstacionamiento)
        topeMasivo = calcularTopeMasivo(tamanioEstacionamiento, tieneElectrico)
        ubicacionesLibres = obtenerUbicacionesGeneralesLibres(espaciosEstacionamiento)
        cantidadVehiculos = topeMasivo
        if cantidadVehiculos > len(ubicacionesLibres):
            cantidadVehiculos = len(ubicacionesLibres)
        if cantidadVehiculos <= 0:
            messagebox.showwarning("Obtener vehículos", "No hay espacios generales disponibles para carga masiva.")
            return
        confirmar = messagebox.askyesno("Obtener vehículos", "Se cargarán " + str(cantidadVehiculos) + " vehículos generales.\n\nDesea continuar?")
        if not confirmar:
            return
        datosVehiculos = obtenerDatosVehiculos(cantidadVehiculos, urlApiMockaroo)
        diccionarioVehiculos = crearDiccionarioVehiculos(diccionario, datosVehiculos, ubicacionesLibres, cantidadVehiculos)
        if len(diccionarioVehiculos) == 0:
            messagebox.showwarning("Obtener vehículos", "No se pudieron generar vehículos.")
            return
        imprimirDiccionarioVehiculos(diccionarioVehiculos)
        agregarDiccionarioGlobal(diccionario, diccionarioVehiculos)
        agregarObjetosEstacionamiento(listaObjetos, diccionarioVehiculos)
        ocuparEspaciosMasivos(diccionarioVehiculos, espaciosEstacionamiento)
        guardarBaseDatos(listaObjetos, archivoBaseDatos)
        cantidadVouchers = crearVouchersMasivos(diccionarioVehiculos, listaObjetos, carpetaVouchers)
        messagebox.showinfo("Obtener vehículos", "Carga masiva finalizada.\n\nVehículos cargados: " + str(len(diccionarioVehiculos)) + "\nVouchers generados: " + str(cantidadVouchers))
    except ValueError:
        messagebox.showerror("Error", "No se pudo obtener la información de vehículos.")
    except Exception:
        messagebox.showerror("Error", "No se pudo completar la carga masiva.")

def alClickCierreDiario(listaObjetos):
    print("Cierre diario")
    messagebox.showinfo("Cierre diario", "Función de cierre diario pendiente.")

def alClickCierrePorTipoPago(listaObjetos):
    print("Cierre por tipo de pago")
    messagebox.showinfo("Cierre por tipo de pago", "Función de cierre por tipo de pago pendiente.")

def alClickExportarCSV(listaObjetos):
    print("Exportar cierre diario a CSV")
    messagebox.showinfo("Exportar CSV", "Función de exportar cierre diario a CSV pendiente.")

def alClickTamanioEstacionamiento(espaciosEstacionamiento):
    print("Tamaño del estacionamiento")
    messagebox.showinfo("Tamaño del estacionamiento", "Función de tamaño del estacionamiento pendiente.")

def alClickTiempoDeGracia():
    print("Tiempo de gracia en minutos")
    messagebox.showinfo("Tiempo de gracia", "Función de tiempo de gracia pendiente.")

def alClickModificarMontoPorHora():
    print("Modificar monto por hora")
    messagebox.showinfo("Modificar monto por hora", "Función de modificar monto por hora pendiente.")

def alClickAcercaDe():
    messagebox.showinfo("Acerca de", "Sistema de Parqueo\nDesarrollado para TP#3.")