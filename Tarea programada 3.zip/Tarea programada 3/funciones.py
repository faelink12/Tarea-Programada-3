import json
import random
import string
from datetime import datetime
from datetime import timedelta
import os
import pickle
import urllib.request
from fpdf import FPDF
import qrcode

def crearPlaca():
    letras = ''.join(random.choices(string.ascii_uppercase, k=3))
    numeros = ''.join(random.choices(string.digits, k=3))
    return letras + "-" + numeros

def crearPlacaUnica(diccionario, diccionarioTemporal):
    placa = crearPlaca()
    placaRepetida = True
    while placaRepetida:
        placaRepetida = False
        if placa in diccionario:
            placaRepetida = True
        if placa in diccionarioTemporal:
            placaRepetida = True
        if placaRepetida:
            placa = crearPlaca()
    return placa

def redondearHaciaArriba(numero):
    entero = int(numero)
    if numero > entero:
        return entero + 1
    return entero

def calcularCantidadEspeciales(tamanioEstacionamiento):
    cantidadEspeciales = redondearHaciaArriba(tamanioEstacionamiento * 0.05)
    if cantidadEspeciales < 2:
        cantidadEspeciales = 2
    if cantidadEspeciales > tamanioEstacionamiento:
        cantidadEspeciales = tamanioEstacionamiento
    return cantidadEspeciales

def calcularTopeMasivo(tamanioEstacionamiento, tieneElectrico):
    cantidadEspeciales = calcularCantidadEspeciales(tamanioEstacionamiento)
    cantidadElectricos = 0
    if tieneElectrico:
        cantidadElectricos = 1
    cantidadGeneral = tamanioEstacionamiento - cantidadEspeciales - cantidadElectricos
    if cantidadGeneral <= 0:
        return 0
    cantidadLibreClientes = redondearHaciaArriba(cantidadGeneral * 0.05)
    topeMasivo = cantidadGeneral - cantidadLibreClientes
    if topeMasivo < 0:
        topeMasivo = 0
    return topeMasivo

def crearFechaHoraEntradaAleatoria():
    horaActual = datetime.now()
    horaApertura = horaActual.replace(hour=7, minute=0, second=0, microsecond=0)
    if horaActual < horaApertura:
        return horaActual.strftime("%Y-%m-%d %H:%M:%S")
    segundosMaximos = int((horaActual - horaApertura).total_seconds())
    if segundosMaximos <= 0:
        return horaActual.strftime("%Y-%m-%d %H:%M:%S")
    segundosAleatorios = random.randint(0, segundosMaximos)
    fechaHoraEntrada = horaApertura + timedelta(seconds=segundosAleatorios)
    return fechaHoraEntrada.strftime("%Y-%m-%d %H:%M:%S")

def obtenerDatoCarro(carro, llave, valorDefecto):
    if llave in carro:
        if carro[llave] is not None:
            if str(carro[llave]).strip() != "":
                return str(carro[llave])
    return valorDefecto

def obtenerDatosVehiculos(cantidadVehiculos, urlApiMockaroo):
    separador = "?"
    if "?" in urlApiMockaroo:
        separador = "&"
    urlCompleta = urlApiMockaroo + separador + "count=" + str(cantidadVehiculos)
    respuesta = urllib.request.urlopen(urlCompleta, timeout=15)
    contenido = respuesta.read().decode("utf-8")
    datosVehiculos = json.loads(contenido)
    if isinstance(datosVehiculos, dict):
        datosConvertidos = []
        datosConvertidos.append(datosVehiculos)
        datosVehiculos = datosConvertidos
    if not isinstance(datosVehiculos, list):
        raise ValueError()
    return datosVehiculos

def crearDiccionarioVehiculos(diccionario, datosVehiculos, ubicacionesLibres, cantidadVehiculos):
    diccionarioVehiculos = {}
    contador = 0
    for carro in datosVehiculos:
        if contador < cantidadVehiculos:
            if contador < len(ubicacionesLibres):
                placa = crearPlacaUnica(diccionario, diccionarioVehiculos)
                marca = obtenerDatoCarro(carro, "Marca", "Toyota")
                color = obtenerDatoCarro(carro, "Color", "Azul")
                tipo = obtenerDatoCarro(carro, "Tipo", "Automovil")
                ubicacion = str(ubicacionesLibres[contador])
                fechaHoraEntrada = crearFechaHoraEntradaAleatoria()
                fechaHoraSalida = ""
                monto = 0
                tipoPago = 0
                diccionarioVehiculos[placa] = [marca, color, tipo, ubicacion, fechaHoraEntrada, fechaHoraSalida, monto, tipoPago]
                contador += 1
    return diccionarioVehiculos

def agregarDiccionarioGlobal(diccionario, diccionarioVehiculos):
    for placa, datos in diccionarioVehiculos.items():
        diccionario[placa] = datos

def guardarBaseDatos(listaObjetos, archivoBaseDatos):
    with open(archivoBaseDatos, "wb") as archivo:
        pickle.dump(listaObjetos, archivo)

def crearCarpetaSiNoExiste(nombreCarpeta):
    if not os.path.exists(nombreCarpeta):
        os.makedirs(nombreCarpeta)

def limpiarNombreArchivo(texto):
    textoLimpio = str(texto)
    caracteresInvalidos = ["\\", "/", ":", "*", "?", '"', "<", ">", "|"]
    for caracter in caracteresInvalidos:
        textoLimpio = textoLimpio.replace(caracter, "-")
    return textoLimpio

def crearTextoQrVoucher(objeto):
    placa = objeto.info[0]
    marca = objeto.info[1]
    tipo = objeto.info[3]
    fechaHoraEntrada = objeto.estadia[1]
    textoQr = "Placa: " + str(placa)
    textoQr += "\nMarca: " + str(marca)
    textoQr += "\nTipo: " + str(tipo)
    textoQr += "\nFecha y hora de entrada: " + str(fechaHoraEntrada)
    return textoQr

def crearNombreVoucher(objeto):
    placa = objeto.info[0]
    fechaHoraEntrada = objeto.estadia[1]
    try:
        fecha = datetime.strptime(fechaHoraEntrada, "%Y-%m-%d %H:%M:%S")
        fechaTexto = fecha.strftime("%d-%m-%Y_%H-%M")
    except ValueError:
        fechaTexto = limpiarNombreArchivo(fechaHoraEntrada)
    nombreArchivo = "voucher_" + str(placa) + "_" + fechaTexto + ".pdf"
    nombreArchivo = limpiarNombreArchivo(nombreArchivo)
    return nombreArchivo

def crearVoucherPdf(objeto, carpetaVouchers):
    crearCarpetaSiNoExiste(carpetaVouchers)
    placa = objeto.info[0]
    marca = objeto.info[1]
    color = objeto.info[2]
    tipo = objeto.info[3]
    ubicacion = objeto.estadia[0]
    fechaHoraEntrada = objeto.estadia[1]
    nombreArchivo = crearNombreVoucher(objeto)
    rutaPdf = os.path.join(carpetaVouchers, nombreArchivo)
    textoQr = crearTextoQrVoucher(objeto)
    imagenQr = qrcode.make(textoQr)
    nombreQr = "qr_" + limpiarNombreArchivo(str(placa)) + ".png"
    rutaQr = os.path.join(carpetaVouchers, nombreQr)
    imagenQr.save(rutaQr)
    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("Arial", "B", 16)
    pdf.cell(0, 10, "Voucher de Estacionamiento", ln=True, align="C")
    pdf.ln(10)
    pdf.set_font("Arial", "", 12)
    pdf.cell(0, 8, "Placa: " + str(placa), ln=True)
    pdf.cell(0, 8, "Marca: " + str(marca), ln=True)
    pdf.cell(0, 8, "Color: " + str(color), ln=True)
    pdf.cell(0, 8, "Tipo: " + str(tipo), ln=True)
    pdf.cell(0, 8, "Ubicacion: " + str(ubicacion), ln=True)
    pdf.cell(0, 8, "Fecha y hora de entrada: " + str(fechaHoraEntrada), ln=True)
    pdf.ln(10)
    pdf.cell(0, 8, "Codigo QR:", ln=True)
    pdf.image(rutaQr, x=80, y=100, w=50, h=50)
    pdf.output(rutaPdf)
    try:
        os.remove(rutaQr)
    except OSError:
        pass
    return rutaPdf

def crearVouchersMasivos(diccionarioVehiculos, listaObjetos, carpetaVouchers):
    cantidadVouchers = 0
    for objeto in listaObjetos:
        placaObjeto = objeto.info[0]
        if placaObjeto in diccionarioVehiculos:
            crearVoucherPdf(objeto, carpetaVouchers)
            cantidadVouchers += 1
    return cantidadVouchers

def imprimirDiccionarioVehiculos(diccionarioVehiculos):
    print("- DICCIONARIO DE VEHICULOS CARGADOS -")
    print(json.dumps(diccionarioVehiculos, indent=4, ensure_ascii=False))
    print("---------------------")